export const content = ['./*.html', './src/**/*.{js,ts}'];
export const theme = {
  extend: {},
};
export const plugins = [];
// This configuration file is for Tailwind CSS, a utility-first CSS framework.
// It specifies the paths to scan for class names, extends the default theme, and includes any plugins you might want to use.